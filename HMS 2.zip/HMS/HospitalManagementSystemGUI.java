import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.regex.*;

public class HospitalManagementSystemGUI {

    static Connection con;

    // DATABASE CONNECTION
    public static void connectDB() {

    try {

        Class.forName("com.mysql.cj.jdbc.Driver");  // ✅ ADD THIS

        con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/hospital_db",
                "root",
                "Prachi@123"
        );

        System.out.println("Connected to DB ✅"); // debug

    } catch(Exception e) {

        e.printStackTrace();

    }
}

    // PASSWORD VALIDATION
    public static boolean validPassword(String password) {

        String pattern =
                "^(?=.*[A-Z])(?=.*[0-9])(?=.*[@#$%^&+=]).{8,}$";

        return Pattern.matches(pattern,password);
    }

    // REGISTER USER
    public static void register(String user,String pass) {

        try {

            if(!validPassword(pass)){

                JOptionPane.showMessageDialog(null,
                        "Password must contain:\n1 Uppercase\n1 Number\n1 Special Character\nMinimum 8 characters");

                return;
            }

            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO users(username,password) VALUES (?,?)"
            );

            ps.setString(1,user);
            ps.setString(2,pass);

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null,"Registration Successful");

        } catch(Exception e){

            JOptionPane.showMessageDialog(null,"User already exists");

        }
    }

    // LOGIN USER
    public static boolean login(String user,String pass){

        try{

            PreparedStatement ps = con.prepareStatement(
                    "SELECT * FROM users WHERE username=? AND password=?"
            );

            ps.setString(1,user);
            ps.setString(2,pass);

            ResultSet rs = ps.executeQuery();

            if(rs.next()){

                return true;

            }

        }catch(Exception e){

            e.printStackTrace();

        }

        return false;
    }

    // GET DOCTOR LIST
    public static String[] getDoctors(){

        try{

            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery(
                    "SELECT name FROM doctors WHERE available=true"
            );

            java.util.ArrayList<String> list = new java.util.ArrayList<>();

            while(rs.next()){

                list.add(rs.getString("name"));

            }

            return list.toArray(new String[0]);

        }catch(Exception e){

            e.printStackTrace();
        }

        return new String[]{"No Doctors Available"};
    }

    // ADD APPOINTMENT
    public static void addAppointment(String name,int age,String phone,String problem,String doctor){

        try{

            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO appointments(name,age,phone,problem,doctor) VALUES (?,?,?,?,?)"
            );

            ps.setString(1,name);
            ps.setInt(2,age);
            ps.setString(3,phone);
            ps.setString(4,problem);
            ps.setString(5,doctor);

            ps.executeUpdate();

            // MAKE DOCTOR UNAVAILABLE
            PreparedStatement ps2 = con.prepareStatement(
                    "UPDATE doctors SET available=false WHERE name=?"
            );

            ps2.setString(1,doctor);
            ps2.executeUpdate();

            JOptionPane.showMessageDialog(null,"Appointment Booked");

        }catch(Exception e){

            e.printStackTrace();

        }
    }

    // LOGIN SCREEN
    public static void loginScreen(){

        JFrame frame = new JFrame("Login");

        frame.setSize(350,250);
        frame.setLayout(new GridLayout(4,2));

        JTextField user = new JTextField();
        JPasswordField pass = new JPasswordField();

        JButton login = new JButton("Login");
        JButton register = new JButton("Register");

        frame.add(new JLabel("Username"));
        frame.add(user);

        frame.add(new JLabel("Password"));
        frame.add(pass);

        frame.add(login);
        frame.add(register);

        login.addActionListener(e -> {

            if(login(user.getText(),new String(pass.getPassword()))){

                frame.dispose();
                dashboard();

            }else{

                JOptionPane.showMessageDialog(frame,"Invalid Login");

            }

        });

        register.addActionListener(e -> {

            register(user.getText(),new String(pass.getPassword()));

        });

        frame.setVisible(true);
    }

    // DASHBOARD
    public static void dashboard(){

        JFrame frame = new JFrame("Hospital Dashboard");

        frame.setSize(300,200);
        frame.setLayout(new GridLayout(2,1));

        JButton appointment = new JButton("Register Appointment");
        JButton logout = new JButton("Logout");

        frame.add(appointment);
        frame.add(logout);

        appointment.addActionListener(e -> {

            frame.dispose();
            appointmentForm();

        });

        logout.addActionListener(e -> {

            frame.dispose();
            loginScreen();

        });

        frame.setVisible(true);
    }

    // APPOINTMENT FORM
    public static void appointmentForm(){

        JFrame frame = new JFrame("Appointment");

        frame.setSize(400,350);
        frame.setLayout(new GridLayout(6,2));

        JTextField name = new JTextField();
        JTextField age = new JTextField();
        JTextField phone = new JTextField();
        JTextField problem = new JTextField();

        JComboBox<String> doctor = new JComboBox<>(getDoctors());

        JButton submit = new JButton("Submit");

        frame.add(new JLabel("Name"));
        frame.add(name);

        frame.add(new JLabel("Age"));
        frame.add(age);

        frame.add(new JLabel("Phone"));
        frame.add(phone);

        frame.add(new JLabel("Problem"));
        frame.add(problem);

        frame.add(new JLabel("Doctor"));
        frame.add(doctor);

        frame.add(new JLabel(""));
        frame.add(submit);

        submit.addActionListener(e -> {

            addAppointment(
                    name.getText(),
                    Integer.parseInt(age.getText()),
                    phone.getText(),
                    problem.getText(),
                    doctor.getSelectedItem().toString()
            );

        });

        frame.setVisible(true);
    }

    // MAIN
    public static void main(String[] args){

        connectDB();
        loginScreen();

    }
}